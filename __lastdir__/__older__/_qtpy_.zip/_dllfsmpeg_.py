import os
import shutil

def replace(source,destine):
    if not os.path.isfile(destine):
        f = open(destine,'w')
        f.close()
        print(destine + " is not exist;")
    shutil.copyfile(source,destine)
    print("copy or replace " + source + " to " + destine + " completed")

version = "6_3_0"
modulename = "_fsmpegbox_"
moduletype = "__device__"

replace("./SuperTools/__plugins__/" + moduletype + "/build-" + modulename + "-Desktop_Qt_" + version + "_MinGW_64_bit-Release/release/" + modulename + ".dll",
        "./build-SuperTools-Desktop_Qt_" + version + "_MinGW_64_bit-Release/release/__plugins__/" + moduletype + "/" + modulename + ".dll")
