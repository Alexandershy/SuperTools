import os
import shutil

def replace(source,destine):
    if os.path.exists(destine):
        shutil.rmtree(destine)
    shutil.copytree(source,destine)
    print("copy " + source + " to " + destine + " completed")

modulename = "_wavdatabox_"

replace("./SuperTools/__api__/__supercore__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supercore__")

replace("./SuperTools/__api__/__supermultimedia__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supermultimedia__")

replace("./SuperTools/__api__/__superprogressbardialog__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superprogressbardialog__")

replace("./SuperTools/__api__/__superwindow__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superwindow__")

replace("./SuperTools/__api__/__superplot__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superplot__")

replace("./SuperTools/__api__/__supernotedialog__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supernotedialog__")

replace("./SuperTools/__api__/__superfiledialog__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superfiledialog__")

replace("./SuperTools/__api__/__superfftw__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superfftw__")

replace("./SuperTools/__api__/__superlogger__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superlogger__")

replace("./SuperTools/__api__/__superfilemanager__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superfilemanager__")

replace("./SuperTools/__api__/__superhook__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superhook__")

replace("./SuperTools/__api__/__supertab__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supertab__")

replace("./SuperTools/__api__/__supergroupbox__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supergroupbox__")
