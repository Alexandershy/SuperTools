import os
import shutil

def replace(source,destine):
    if os.path.exists(destine):
        shutil.rmtree(destine)
    shutil.copytree(source,destine)
    print("copy " + source + " to " + destine + " completed")

modulename = "_relaybox_"

replace("./SuperTools/__api__/__supercore__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supercore__")

replace("./SuperTools/__api__/__superserial__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superserial__")

replace("./SuperTools/__api__/__superlogger__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superlogger__")

replace("./SuperTools/__api__/__supertab__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supertab__")

replace("./SuperTools/__api__/__supergroupbox__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supergroupbox__")

replace("./SuperTools/__api__/__supernotedialog__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supernotedialog__")

replace("./SuperTools/__api__/__superfiledialog__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superfiledialog__")

replace("./SuperTools/__api__/__superwindow__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superwindow__")
