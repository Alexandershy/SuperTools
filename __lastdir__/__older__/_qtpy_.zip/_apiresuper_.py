import os
import shutil

def replace(source,destine):
    if os.path.exists(destine):
        shutil.rmtree(destine)
    shutil.copytree(source,destine)
    print("copy " + source + " to " + destine + " completed")

modulename = "_resuper_"
moduletype = "__other__"

replace("./SuperTools/__api__/__supercore__",
        "./SuperTools/__plugins__/" + moduletype + "/" + modulename + "/__supercore__")
