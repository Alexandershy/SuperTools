import os
import shutil

def replace(source,destine):
    if os.path.exists(destine):
        shutil.rmtree(destine)
    shutil.copytree(source,destine)
    print("copy " + source + " to " + destine + " completed")

modulename = "_ledanalyserbox_"

replace("./SuperTools/__api__/__supercore__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supercore__")

replace("./SuperTools/__api__/__superserial__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superserial__")

replace("./SuperTools/__api__/__superlogger__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__superlogger__")

replace("./SuperTools/__api__/__supertab__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supertab__")

replace("./SuperTools/__api__/__supergroupbox__",
        "./SuperTools/__plugins__/__device__/" + modulename + "/__supergroupbox__")
